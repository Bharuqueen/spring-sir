package com.cg.cust.service;

import java.util.List;

import com.cg.cust.bean.Customer;

public interface CustomerService {
	List<Customer> getAllCustomer();

}
